import React, { useState } from "react";
import "./sidebar.css";
import { IoMenuOutline, IoFlower } from "react-icons/io5";

const SideBar = () => {
  const [sidebarWidth, setSidebarWidth] = useState("80px");
  const [close, setClose] = useState(false);
  const [open, setOpen] = useState(true);

  const [position, setPosition] = useState('static');

  const sideBarOpen = () => {
    setSidebarWidth("250px");
    setClose(true);
    setOpen(false);
    setPosition('fixed');
  };
  const closeSidebar = () => {
    setSidebarWidth("80px");
    setPosition('static');
    setClose(false);
    setOpen(true);
  };

  return (
    <>
      <div className="sidebar" style={{ width: sidebarWidth, position: position, backgroundColor:'#E9E9E9' }}>
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasExampleLabel"></h5>

          {close ? (
            <button
              type="button"
              class="btn-close text-reset"
              data-bs-dismiss="offcanvas"
              aria-label="Close"
              onClick={closeSidebar}
            ></button>
          ) : (
            <span
              className="mx-auto"
              style={{ fontSize: "1.5rem" }}
              onClick={sideBarOpen}
            >
              <IoMenuOutline />
            </span>
          )}
        </div>
        <div className="sidebarBody">
          <ul className="side-li">


            <li>
              {close ? (
                <p>
               
                  <span style={{ fontSize: "1.5rem" }}>
                   
                    <IoFlower />
                  </span>
                  <span className="ms-2">My Reports</span>
                </p>
              ) : (
                <span style={{ fontSize: "1.5rem" }}>
                   
                    <IoFlower />
                  </span>
              )}
            </li>





            <li>
              {" "}
              {close ? (
                <p>
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
                  <span className="ms-2">Create a report:  Market</span>
                </p>
              ) : (
               <span style={{ fontSize: "1.5rem" }}>
                   
                    <IoFlower />
                  </span>
              )}{" "}
            </li>
            <li>
              {" "}
              {close ? (
                <p>
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
                  <span className="ms-2">Create a report:  Market</span>
                </p>
              ) : (
                <span style={{ fontSize: "1.5rem" }}>
                   
                    <IoFlower />
                  </span>
              )}{" "}
            </li>
            <li>
              {close ? (
                <p>
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
                  <span className="ms-2">Create a report:  Market</span>
                </p>
              ) : (
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
              )}{" "}
            </li>
            <li>
              {close ? (
                <p>
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
                  <span className="ms-2">Create a report:  Market</span>
                </p>
              ) : (
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
              )}{" "}
            </li>
            <li>
              {close ? (
                <p>
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
                  <span className="ms-2">Create a report:  Market</span>
                </p>
              ) : (
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
              )}{" "}
            </li>
            <li>
              {close ? (
                <p>
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
                  <span className="ms-2">Create a report:  Market</span>
                </p>
              ) : (
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
              )}{" "}
            </li>
            <li>
              {close ? (
                <p>
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
                  <span className="ms-2">Create a report: Market</span>
                </p>
              ) : (
                <span style={{ fontSize: "1.5rem" }}>
                   
                   <IoFlower />
                 </span>
              )}{" "}
            </li>
          </ul>
        </div>
      </div>
    </>
  );
};

export default SideBar;
