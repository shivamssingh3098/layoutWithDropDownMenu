import React from "react";
import "./chapterSidebarStyle.css";
const ChapterSideBar = () => {
  return (
    <>
      <div className="chapter-side-bar">
        <div className="row">
          <div className="col text-center mt-4 ">
            <p className="" style={{ fontWeight: "bold" }}>
              Create a report: ABC Market
            </p>
          </div>
        </div>
        <div className="row">
          <div className="col p-3">
            <p style={{ fontWeight: "bold", color: "red" }}>Chapters </p>
            <ul className="chapters-list">
              <li>
                {" "}
                Chapter 1
                <div class="dropdown me-5" style={{ float: "right" }}>
                  <a
                    class=" dropdown-toggle"
                    href="#"
                    role="button"
                    id="dropdownMenuLink"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  ></a>

                  <ul
                    class="dropdown-menu list-action-li"
                    aria-labelledby="dropdownMenuLink"
                  >
                    <li>
                      <a class="dropdown-item" href="#">
                        Add
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Delete
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Update
                      </a>
                    </li>
                  </ul>
                </div>
                <ul>
                  <li>
                    Sub Chapter
                    <div class="dropdown me-5" style={{ float: "right" }}>
                  <a
                    class=" dropdown-toggle"
                    href="#"
                    role="button"
                    id="dropdownMenuLink"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  ></a>

                  <ul
                    class="dropdown-menu list-action-li"
                    aria-labelledby="dropdownMenuLink"
                  >
                    <li>
                      <a class="dropdown-item" href="#">
                        Add
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Delete
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Update
                      </a>
                    </li>
                  </ul>
                </div>

                  </li>
                </ul>{" "}
              </li>
              <li>Chapter 2       <div class="dropdown me-5" style={{ float: "right" }}>
                  <a
                    class=" dropdown-toggle"
                    href="#"
                    role="button"
                    id="dropdownMenuLink"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  ></a>

                  <ul
                    class="dropdown-menu list-action-li"
                    aria-labelledby="dropdownMenuLink"
                  >
                    <li>
                      <a class="dropdown-item" href="#">
                        Add
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Delete
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Update
                      </a>
                    </li>
                  </ul>
                </div></li>
              <li>Chapter 3
              <div class="dropdown me-5" style={{ float: "right" }}>
                  <a
                    class=" dropdown-toggle"
                    href="#"
                    role="button"
                    id="dropdownMenuLink"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  ></a>

                  <ul
                    class="dropdown-menu list-action-li"
                    aria-labelledby="dropdownMenuLink"
                  >
                    <li>
                      <a class="dropdown-item" href="#">
                        Add
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Delete
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Update
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li>Chapter 4
              <div class="dropdown me-5" style={{ float: "right" }}>
                  <a
                    class=" dropdown-toggle"
                    href="#"
                    role="button"
                    id="dropdownMenuLink"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  ></a>

                  <ul
                    class="dropdown-menu list-action-li"
                    aria-labelledby="dropdownMenuLink"
                  >
                    <li>
                      <a class="dropdown-item" href="#">
                        Add
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Delete
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Update
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li>Chapter 5
              <div class="dropdown me-5" style={{ float: "right" }}>
                  <a
                    class=" dropdown-toggle"
                    href="#"
                    role="button"
                    id="dropdownMenuLink"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  ></a>

                  <ul
                    class="dropdown-menu list-action-li"
                    aria-labelledby="dropdownMenuLink"
                  >
                    <li>
                      <a class="dropdown-item" href="#">
                        Add
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Delete
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        Update
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};

export default ChapterSideBar;
