import logo from "./logo.svg";
import "./App.css";
import Header from "./components/header/Header";
import SideBar from "./components/sideBar/SideBar";
import ChapterSideBar from "./components/chapterSideBar/ChapterSideBar";
import WorkAreaHeader from "./components/workArea.jsx/WorkAreaHeader";

function App() {
  return (
    <>
      <Header />
      <div className="d-flex justify-content-start">
      <SideBar />
      <ChapterSideBar />
      <WorkAreaHeader/>
      </div>
      
    </>
  );
}

export default App;
